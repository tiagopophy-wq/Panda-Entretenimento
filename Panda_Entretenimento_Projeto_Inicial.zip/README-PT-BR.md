# Panda Entretenimento — projeto inicial

Este é o projeto-fonte inicial do aplicativo Android, com identidade visual preta, dourada e branca e telas-base para Início, TV, Esportes e Servidores.

## Estado desta versão
- Interface inicial em Jetpack Compose.
- Navegação entre as seções.
- Formulário visual para servidor M3U ou Xtream Codes.
- Dependência Media3 incluída para a futura reprodução.
- Fluxo GitHub Actions incluído para compilar um APK de teste na nuvem.

**Importante:** esta versão ainda NÃO autentica, NÃO salva credenciais, NÃO baixa listas e NÃO reproduz canais. Esses recursos serão adicionados e testados em etapas. Use somente listas e credenciais de serviços aos quais você tem autorização.

## Como gerar um APK pelo celular usando GitHub
1. Entre em https://github.com pelo navegador e crie uma conta, se ainda não tiver.
2. Crie um repositório novo chamado `PandaEntretenimento`.
3. Envie os arquivos deste ZIP para o repositório, mantendo as pastas.
4. Abra a aba **Actions** do repositório.
5. Selecione **Build Panda APK** e toque em **Run workflow** (ou aguarde o build após enviar os arquivos).
6. Quando terminar, abra a execução e baixe o artefato `panda-entretenimento-debug-apk`.
7. Extraia o ZIP do artefato: o arquivo `app-debug.apk` será o instalador de teste.

O primeiro build pode levar alguns minutos. Para publicar na Play Store ou distribuir uma versão final, será necessário configurar assinatura de release e revisar permissões e políticas.

## Requisitos
- Android Studio/Gradle para compilação local, ou GitHub Actions para compilação na nuvem.
- JDK 17.
- Android SDK 35.
