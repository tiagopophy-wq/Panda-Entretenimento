package br.com.pandaentretenimento

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PandaBlack = Color(0xFF101114)
private val PandaPanel = Color(0xFF1B1D22)
private val PandaGold = Color(0xFFE0B84F)
private val PandaWhite = Color(0xFFF7F7F5)
private val PandaMuted = Color(0xFFB8B8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PandaApp() }
    }
}

@Composable
fun PandaApp() {
    var page by remember { mutableStateOf("Início") }
    var serverType by remember { mutableStateOf("Xtream Codes") }
    var serverName by remember { mutableStateOf("Meu servidor") }
    var serverUrl by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Adicione os dados fornecidos pelo administrador.") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PandaGold,
            background = PandaBlack,
            surface = PandaPanel,
            onPrimary = PandaBlack,
            onBackground = PandaWhite,
            onSurface = PandaWhite
        )
    ) {
        Scaffold(
            containerColor = PandaBlack,
            bottomBar = {
                NavigationBar(containerColor = PandaPanel, contentColor = PandaWhite) {
                    listOf("Início", "TV", "Esportes", "Servidores").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "TV" -> Icons.Default.LiveTv
                                        "Esportes" -> Icons.Default.EmojiEvents
                                        "Servidores" -> Icons.Default.Dns
                                        else -> Icons.Default.Home
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PandaGold,
                                selectedTextColor = PandaGold,
                                indicatorColor = Color(0xFF39301B),
                                unselectedIconColor = PandaMuted,
                                unselectedTextColor = PandaMuted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🐼", fontSize = 34.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PANDA", color = PandaGold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("ENTRETENIMENTO", color = PandaWhite, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF263A2B), shape = RoundedCornerShape(50)) {
                        Text("BETA", color = Color(0xFF8BE0A0), modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                when (page) {
                    "Servidores" -> ServerScreen(
                        serverType, { serverType = it }, serverName, { serverName = it },
                        serverUrl, { serverUrl = it }, username, { username = it },
                        password, { password = it }, message,
                        { message = "Configuração preenchida. A conexão real será ativada na próxima etapa, após validarmos o formato e o servidor." }
                    )
                    "TV" -> InfoScreen("TV ao vivo", "Aqui aparecerão os canais das listas autorizadas que você adicionar. A reprodução será implementada após a configuração dos servidores.")
                    "Esportes" -> InfoScreen("Agenda esportiva", "Área preparada para jogos do dia, calendário do UFC e eventos importantes. Na próxima etapa vamos conectar uma fonte de dados esportivos confiável.")
                    else -> HomeScreen(
                        onServers = { page = "Servidores" },
                        onTv = { page = "TV" },
                        onSports = { page = "Esportes" }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onServers: () -> Unit, onTv: () -> Unit, onSports: () -> Unit) {
    Surface(color = PandaPanel, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("SEU ENTRETENIMENTO", color = PandaGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Tudo em um só lugar.", color = PandaWhite, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("TV, esportes e programação em uma experiência simples e rápida.", color = PandaMuted, fontSize = 14.sp)
            Button(onClick = onServers, colors = ButtonDefaults.buttonColors(containerColor = PandaGold), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AddLink, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("CONFIGURAR SERVIDOR", fontWeight = FontWeight.Bold)
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FeatureCard("TV ao vivo", "Canais e categorias", Icons.Default.LiveTv, onTv, Modifier.weight(1f))
        FeatureCard("Esportes", "Jogos e UFC", Icons.Default.EmojiEvents, onSports, Modifier.weight(1f))
    }
    Surface(color = PandaPanel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("PRÓXIMAS NOVIDADES", color = PandaGold, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("• Favoritos e histórico\n• Troca rápida de servidores\n• Guia de programação\n• Compatibilidade com controle remoto", color = PandaMuted, lineHeight = 24.sp)
        }
    }
    Text("PANDA ENTRETENIMENTO  •  VERSÃO 0.1.0", color = PandaMuted, fontSize = 10.sp)
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier.clickable { onClick() }, color = PandaPanel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = PandaGold, modifier = Modifier.size(28.dp))
            Text(title, color = PandaWhite, fontWeight = FontWeight.Bold)
            Text(subtitle, color = PandaMuted, fontSize = 11.sp)
        }
    }
}

@Composable
fun ServerScreen(
    type: String, onType: (String) -> Unit,
    name: String, onName: (String) -> Unit,
    url: String, onUrl: (String) -> Unit,
    user: String, onUser: (String) -> Unit,
    pass: String, onPass: (String) -> Unit,
    message: String, onSave: () -> Unit
) {
    Text("SERVIDORES", color = PandaGold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    Text("Conecte sua lista", color = PandaWhite, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
    Text("Use somente listas e credenciais fornecidas por um serviço que você tem autorização para acessar.", color = PandaMuted, fontSize = 13.sp)
    Text("FORMATO DA LISTA", color = PandaGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Xtream Codes", "M3U").forEach { option ->
            FilterChip(
                selected = type == option,
                onClick = { onType(option) },
                label = { Text(option) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = PandaGold,
                    selectedLabelColor = PandaBlack,
                    labelColor = PandaWhite
                )
            )
        }
    }
    PandaField("Nome do servidor", name, onName)
    PandaField(if (type == "M3U") "Endereço da lista M3U" else "Endereço do servidor (URL)", url, onUrl)
    if (type == "Xtream Codes") {
        PandaField("Usuário", user, onUser)
        PandaField("Senha", pass, onPass, secret = true)
    }
    Button(onClick = onSave, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PandaGold)) {
        Icon(Icons.Default.Save, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("SALVAR CONFIGURAÇÃO", color = PandaBlack, fontWeight = FontWeight.Bold)
    }
    Surface(color = Color(0xFF252317), shape = RoundedCornerShape(12.dp)) {
        Text(message, color = PandaGold, modifier = Modifier.padding(14.dp), fontSize = 12.sp)
    }
    Text("Nota: nesta versão inicial, o formulário visual está pronto. A validação, armazenamento seguro, conexão e reprodução serão implementados nas próximas etapas.", color = PandaMuted, fontSize = 11.sp)
}

@Composable
fun PandaField(label: String, value: String, onValue: (String) -> Unit, secret: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = PandaMuted, fontSize = 12.sp)
        OutlinedTextField(
            value = value, onValueChange = onValue,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PandaGold,
                unfocusedBorderColor = Color(0xFF55565A),
                focusedTextColor = PandaWhite,
                unfocusedTextColor = PandaWhite,
                focusedLabelColor = PandaGold,
                cursorColor = PandaGold
            )
        )
    }
}

@Composable
fun InfoScreen(title: String, description: String) {
    Text(title.uppercase(), color = PandaGold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
    Text(description, color = PandaWhite, fontSize = 16.sp, lineHeight = 25.sp)
    Surface(color = PandaPanel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Schedule, tint = PandaGold, contentDescription = null, modifier = Modifier.size(30.dp))
            Text("Conteúdo em preparação", color = PandaWhite, fontWeight = FontWeight.Bold)
            Text("Esta seção será conectada a fontes de programação e dados esportivos na próxima etapa.", color = PandaMuted, fontSize = 13.sp)
        }
    }
}
